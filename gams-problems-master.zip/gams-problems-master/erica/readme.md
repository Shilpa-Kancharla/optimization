Young MBA Erica Cudahy may invest up to $1000. She can invest her money in stocks and loans. Each dollar invested in stocks 
yields 10 cents of profit, and each dollar invested in a loan yields 15 cents of profit. At least 30% of all money invested 
must be in stocks, and at least $400 must be in loans. Formulate an LP to maximize total profit earned from Erica’s investment.

In the GAMS code, declare two positive variables, stock and loan, to denote the amount of money to put in stock and loan 
respectively. Also declare a free variable called profit to denote the total profit. Model and solve as an LP
